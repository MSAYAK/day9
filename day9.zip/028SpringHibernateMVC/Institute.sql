Create table institute(InCode number primary key,DiseCode number,In_Uni number ,Password varchar(10),
C_Password varchar(10),Add_Line1 varchar(10),Add_Line2 varchar(10),City varchar(10),Pincode number)


insert into institute values(1,123,1,"abc","abc","dw","erf","vij",520001);

select * from institute;