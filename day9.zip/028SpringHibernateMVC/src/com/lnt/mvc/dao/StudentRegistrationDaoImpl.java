package com.lnt.mvc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;

//import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.MinisterLogin;
import com.lnt.mvc.model.NodalOfficer;
import com.lnt.mvc.model.Registration;
import com.lnt.mvc.model.ScholarshipApplicationForm;
//import com.lnt.mvc.model.Registration;
import com.lnt.mvc.model.StudentRegistration;





@Repository
public class StudentRegistrationDaoImpl implements StudentRegistrationDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	 

	

	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory=sf;
	}	
	
	 
		private static final Logger logger = 			
				LoggerFactory.getLogger(StudentRegistrationDaoImpl.class);
		
		@Override
		public void save(StudentRegistration s) {
			
			Session session = this.sessionFactory.openSession();
			Transaction tx=session.beginTransaction();
			session.save(s);
			logger.info("Student saved successfully, Person Details="
			+ s);
			tx.commit();
			Transaction tx1=session.beginTransaction();
			String query1="update ScholarshipApplicationForm s set s.requestStatus='PENDING'";
			Query q1=session.createQuery(query1);
			System.out.println("hi1");
			q1.executeUpdate();
			tx1.commit();
			session.close();
			
			
			
			
			
			
	}

		@Override
		public boolean verifyUser(Integer aadharno, String password) {
			Session session = this.sessionFactory.openSession();
			
	 
			
			  System.out.println("hello");
			  String query="from StudentRegistration a where a.aadharno=:aadharno and a.password=:password";
		
			  Query q=session.createQuery(query);
			  q.setInteger("aadharno",aadharno);
			  q.setString("password", password);
			  List<StudentRegistration>list=q.list();
			  System.out.println("hello");
	if(list.size()==0)
	{
		  return false;
	}
	session.close();
		  return true;

	}

		@Override
		public boolean verifyMinister(String username, String password) {
				Session session = this.sessionFactory.openSession();
				
		 

				  System.out.println("hello");	
				  
				  String query="Select * from minister a where a.username=:username and a.password=:password";
				  SQLQuery q = session.createSQLQuery(query);				  
				  q.setParameter("username", username);
				  q.setParameter("password", password);
				 // Query q=session.createQuery(query);
				  //q.setString("username",username);
				 // q.setString("password", password);
				 
				  System.out.println("hello");
				  List<MinisterLogin>list1=q.list();
					if(list1.size()==0){
						  return false;
					}
					session.close();
			     return true;

		}

		@Override
		public boolean verifyOfficer(String officerusername, String officerpassword) {
	
			
			Session session = this.sessionFactory.openSession();
			
			 

			  System.out.println("hello");	
			  
			  String query="Select * from officer b where b.officerusername=:officerusername and b.officerpassword=:officerpassword";
			  SQLQuery q = session.createSQLQuery(query);				  
			  q.setParameter("officerusername", officerusername);
			  q.setParameter("officerpassword", officerpassword);
			 // Query q=session.createQuery(query);
			  //q.setString("username",username);
			 // q.setString("password", password);
			 
			  System.out.println("hello");
			  List<NodalOfficer>list1=q.list();
				if(list1.size()==0){
					  return false;
				}
				session.close();
		     return true;
			
			
			
			
			 
		}

		@Override
		public boolean verifyInstitute(String In_Name, String Password) {

			Session session = this.sessionFactory.openSession();
			
			 

			  System.out.println("hello insitute");	
			  
			  String query="Select * from institute c where c.In_Name=:In_Name and c.Password=:Password";
			  SQLQuery q = session.createSQLQuery(query);				  
			  q.setParameter("In_Name",In_Name);
			  q.setParameter("Password",Password);
		  System.out.println("hello");
			  List<Registration>list2=q.list();
				if(list2.size()==0){
					  return false;
				}
				session.close();
		     return true;
			
			
			
		}

		@Override
		public void getById(Integer aadharno) {
			
			Session session = this.sessionFactory.openSession();
			  
			  Transaction tx=session.beginTransaction();
			  
			  String query="from ScholarshipApplicationForm a where a.aadharno=:aadharno  "; 
			  Query q=session.createQuery(query); 
			 
			  
			  tx.commit();
			  session.close();
			  
			  
			  
			
		}

		
		
		
		@Override
		public StudentRegistration getStudent(int aadharno, String password) {
			Session session = this.sessionFactory.openSession();
			String query = "from StudentRegistration s where s.aadharno=:aadharno and s.password=:password";
			Query q = session.createQuery(query);
			 q.setInteger("aadharno",aadharno);
			  q.setString("password", password);
			  List<StudentRegistration> l=q.list();

			if (l.size() == 0) {
				return null;
			}
			StudentRegistration student = (StudentRegistration) l.get(0);
			session.close();
			return student;
		}
	}

		
	
	/*
	 * @Override public List<ScholarshipApplicationForm> applicationform() {
	 * 
	 * 
	 * 
	 * Session session = this.sessionFactory.openSession();
	 * 
	 * Transaction tx=session.beginTransaction();
	 * 
	 * String query="from ScholarshipApplicationForm "; Query
	 * q=session.createQuery(query); List<ScholarshipApplicationForm>
	 * applicationList=q.list();
	 * 
	 * tx.commit(); session.close();
	 * 
	 * 
	 * return applicationList;
	 * 
	 * }
	 */

		
		
		
		
		
		
			


	 

	
		 
		 


