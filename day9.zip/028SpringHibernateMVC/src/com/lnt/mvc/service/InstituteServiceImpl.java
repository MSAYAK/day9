package com.lnt.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.mvc.dao.InstituteDao;
import com.lnt.mvc.model.ScholarshipApplicationForm;
@Service
public class InstituteServiceImpl implements InstituteService {
private InstituteDao instituteDao;
@Autowired

public void setInstituteDao(InstituteDao instituteDao) {
	this.instituteDao = instituteDao;
}

	@Override
	public List<ScholarshipApplicationForm> listapplications() {
		
		return this.instituteDao.listapplications();
	}

	

	@Override
	public void acceptApplicaton(int studentId) {
		// TODO Auto-generated method stub
		this.instituteDao.acceptApplicaton(studentId);
	}

	@Override
	public void rejectApplication(int studentId) {
		// TODO Auto-generated method stub
		this.instituteDao.rejectApplication(studentId);
		
	}

	@Override
	public ScholarshipApplicationForm getApplication(int studentId) {
		
		return this.instituteDao.getApplication(studentId);
	}

}
