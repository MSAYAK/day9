package com.lnt.mvc.model;

import java.io.Serializable;
import java.sql.Blob;




//import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
@Entity
@Table(name="DOCUMENTS_LIST")
public class ScholarshipApplicationForm implements Serializable{	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
private Integer studentId;
private String studentName;
private String instituteName;
private String dob;
private String emailId;
private int mobileno;
private String studentState;
private int xMarks;
private int xIIMarks;
private int degreeMarks;
private int familyAnnualIncome;
private String caste;

private int studentstatus;
private int institutestatus;
private int officerstatus;
private int ministerstatus;
private String requestStatus;





public ScholarshipApplicationForm() {
	super();
}





public ScholarshipApplicationForm(Integer studentId, String studentName, String instituteName, String dob,
		String emailId, int mobileno, String studentState, int xMarks, int xIIMarks, int degreeMarks,
		int familyAnnualIncome, String caste, int studentstatus, int institutestatus, int officerstatus,
		int ministerstatus, String requestStatus) {
	super();
	this.studentId = studentId;
	this.studentName = studentName;
	this.instituteName = instituteName;
	this.dob = dob;
	this.emailId = emailId;
	this.mobileno = mobileno;
	this.studentState = studentState;
	this.xMarks = xMarks;
	this.xIIMarks = xIIMarks;
	this.degreeMarks = degreeMarks;
	this.familyAnnualIncome = familyAnnualIncome;
	this.caste = caste;
	this.studentstatus = studentstatus;
	this.institutestatus = institutestatus;
	this.officerstatus = officerstatus;
	this.ministerstatus = ministerstatus;
	this.requestStatus = requestStatus;
}





public Integer getStudentId() {
	return studentId;
}





public void setStudentId(Integer studentId) {
	this.studentId = studentId;
}





public String getStudentName() {
	return studentName;
}





public void setStudentName(String studentName) {
	this.studentName = studentName;
}





public String getInstituteName() {
	return instituteName;
}





public void setInstituteName(String instituteName) {
	this.instituteName = instituteName;
}





public String getDob() {
	return dob;
}





public void setDob(String dob) {
	this.dob = dob;
}





public String getEmailId() {
	return emailId;
}





public void setEmailId(String emailId) {
	this.emailId = emailId;
}





public int getMobileno() {
	return mobileno;
}





public void setMobileno(int mobileno) {
	this.mobileno = mobileno;
}





public String getStudentState() {
	return studentState;
}





public void setStudentState(String studentState) {
	this.studentState = studentState;
}





public int getxMarks() {
	return xMarks;
}





public void setxMarks(int xMarks) {
	this.xMarks = xMarks;
}





public int getxIIMarks() {
	return xIIMarks;
}





public void setxIIMarks(int xIIMarks) {
	this.xIIMarks = xIIMarks;
}





public int getDegreeMarks() {
	return degreeMarks;
}





public void setDegreeMarks(int degreeMarks) {
	this.degreeMarks = degreeMarks;
}





public int getFamilyAnnualIncome() {
	return familyAnnualIncome;
}





public void setFamilyAnnualIncome(int familyAnnualIncome) {
	this.familyAnnualIncome = familyAnnualIncome;
}





public String getCaste() {
	return caste;
}





public void setCaste(String caste) {
	this.caste = caste;
}





public int getStudentstatus() {
	return studentstatus;
}





public void setStudentstatus(int studentstatus) {
	this.studentstatus = studentstatus;
}





public int getInstitutestatus() {
	return institutestatus;
}





public void setInstitutestatus(int institutestatus) {
	this.institutestatus = institutestatus;
}





public int getOfficerstatus() {
	return officerstatus;
}





public void setOfficerstatus(int officerstatus) {
	this.officerstatus = officerstatus;
}





public int getMinisterstatus() {
	return ministerstatus;
}





public void setMinisterstatus(int ministerstatus) {
	this.ministerstatus = ministerstatus;
}





public String getRequestStatus() {
	return requestStatus;
}





public void setRequestStatus(String requestStatus) {
	this.requestStatus = requestStatus;
}





@Override
public String toString() {
	return "ScholarshipApplicationForm [studentId=" + studentId + ", studentName=" + studentName + ", instituteName="
			+ instituteName + ", dob=" + dob + ", emailId=" + emailId + ", mobileno=" + mobileno + ", studentState="
			+ studentState + ", xMarks=" + xMarks + ", xIIMarks=" + xIIMarks + ", degreeMarks=" + degreeMarks
			+ ", familyAnnualIncome=" + familyAnnualIncome + ", caste=" + caste + ", studentstatus=" + studentstatus
			+ ", institutestatus=" + institutestatus + ", officerstatus=" + officerstatus + ", ministerstatus="
			+ ministerstatus + ", requestStatus=" + requestStatus + "]";
}








 







	

}
