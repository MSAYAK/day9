package com.lnt.mvc.model;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Lob;

public class FileUpload {
	@Column(name = "File")
	@Lob
	private Blob content;

}
